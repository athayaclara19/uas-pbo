public interface Endorse {
    void endorseFotoStory();
    void endorseVideoStory();
    void endorseFotoFeed();
    void endorseVideoFeed();
}
